[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**XVector** is an R/Bioconductor package that provides the foundation of external vector representation and manipulation in Bioconductor.

See https://bioconductor.org/packages/XVector for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

