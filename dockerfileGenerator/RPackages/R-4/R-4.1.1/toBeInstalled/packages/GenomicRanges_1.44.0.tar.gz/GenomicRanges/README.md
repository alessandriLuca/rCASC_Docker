[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**GenomicRanges** is an R/Bioconductor package for representing and manipulating genomic intervals.

See https://bioconductor.org/packages/GenomicRanges for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

