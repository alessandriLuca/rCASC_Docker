GENOME <- "ce4"
ORGANISM <- "Caenorhabditis elegans"
ASSEMBLED_MOLECULES <- paste0("chr", c(as.character(as.roman(1:5)), "X", "M"))
CIRC_SEQS <- "chrM"

