### =========================================================================
### Row-level and column-level summary
### -------------------------------------------------------------------------
###

setGeneric("colSums")
setGeneric("rowSums")
setGeneric("colMeans")
setGeneric("rowMeans")

