### R code from vignette source 'readGTF.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: readGTF.Rnw:36-37
###################################################
options(width=60)


