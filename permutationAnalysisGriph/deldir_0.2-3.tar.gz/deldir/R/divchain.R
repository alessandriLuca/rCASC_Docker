divchain <- function(x,...) {
    UseMethod("divchain")
}
