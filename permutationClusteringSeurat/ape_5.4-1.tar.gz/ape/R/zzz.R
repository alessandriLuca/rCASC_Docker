## zzz.R (2009-01-12)

##   Library Loading

## Copyright 2003-2009 Emmanuel Paradis

## This file is part of the R-package `ape'.
## See the file ../COPYING for licensing issues.

.PlotPhyloEnv <- new.env()
