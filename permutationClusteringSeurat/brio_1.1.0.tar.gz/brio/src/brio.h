#pragma once

#include <stdio.h>

FILE* open_with_widechar_on_windows(const char* txt, const char* mode);
