#' @useDynLib sitmo, .registration=TRUE
#' @importFrom Rcpp sourceCpp
"_PACKAGE"
