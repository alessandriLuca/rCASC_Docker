library(testthat)
library(griph)

test_check("griph")
