library(methods)
setGeneric('describe', function(x) standardGeneric('describe'))

setGeneric('attach.resource', 
  function(obj, ...) standardGeneric('attach.resource'))
