data("ER_692")
a = QUIC(S, rho = 1.0, path = c(1.0, 0.9, 0.8, 0.7, 0.6, 0.5), tol = 1e-8,
  msg = 2, maxIter = 1000)
