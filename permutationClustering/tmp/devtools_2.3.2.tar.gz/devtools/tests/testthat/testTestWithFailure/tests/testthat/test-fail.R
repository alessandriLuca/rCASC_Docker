context("failure")

test_that("failing test", {
  fail("Broken")
})
