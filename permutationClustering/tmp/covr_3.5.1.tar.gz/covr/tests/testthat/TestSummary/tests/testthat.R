library(testthat)
library("TestSummary")

test_check("TestSummary")
