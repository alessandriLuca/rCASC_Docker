lhs <- function(formula){
  update(formula,.~NULL)
}
