rhs <- function(formula){
  update(formula,NULL~.)
}
